<?php $__env->startSection('main'); ?>
<div class="row">
   <div class="col-sm-8 offset-sm-2">
      <h1 class="p-3 mb-2 bg-primary text-white" style="
    text-align: center;">AG Digital Health Services - EMR</h1>
     <a class="btn btn-primary" href="<?php echo e(route('info')); ?>">New Submission</a><br><br/>
          <div class="push-top">
        <?php if(session()->get('success')): ?>
          <div class="alert alert-success">
            <?php echo e(session()->get('success')); ?>  
          </div><br />
        <?php endif; ?>
        
      <div>
   </div>
</div></div>

<div style="overflow-x: scroll;"">
    <table class="table table-striped" style="width: 100%;border-collapse: collapse;" >
          <thead class="thread-dark" style="white-space: nowrap;">
              <tr>
                 <th scope="col"> ID</th>
                <th scope="col"> Name</th>
                <th scope="col"> Gender</th>
                <th scope="col"> Member</th>
                <th scope="col"> DOB</th>
                <th scope="col"> Age</th>
                <th scope="col"> Address</th>
                <th scope="col"> Mobile Number</th>
                <th scope="col"> Marital Status</th>
                <th scope="col"> Number of Children</th>
                <th scope="col"> Height</th>
                <th scope="col"> Weight</th>
                <th scope="col"> Blood Pressure</th>
                <th scope="col"> Is Known Diabetic</th>
                <th scope="col"> Major Complain of today</th>
                <th scope="col"> Observation by Medical Assistant</th>
                <th scope="col"> Suggestion given</th>
                <th scope="col"> Schedule for VC</th>
                <th scope="col"> Suggestion from medical officer</th>
                <th class="text-center">Action</th>
              </tr>
          </thead>
          <tbody style="white-space: nowrap;">
              <?php $__currentLoopData = $infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td> <?php echo e($info->id); ?></td>
                  <td> <?php echo e($info->name); ?></td>
                  <td> <?php echo e($info->gender); ?></td>
                  <td> <?php echo e($info->member); ?></td>
                  <td> <?php echo e($info->dob); ?></td>
                  <td> <?php echo e($info->age); ?></td>
                  <td> <?php echo e($info->address); ?></td>
                  <td> <?php echo e($info->mobile_number); ?></td>
                  <td> <?php echo e($info->marital_status); ?></td>
                  <td> <?php echo e($info->number_of_children); ?></td>
                  <td> <?php echo e($info->height); ?></td>
                  <td> <?php echo e($info->weight); ?></td>
                  <td> <?php echo e($info->blood_pressure); ?></td>
                  <td> <?php echo e($info->is_diabetic); ?></td>
                  <td> <?php echo e($info->complain); ?></td>
                  <td> <?php echo e($info->obs_medical_assistant); ?></td>
                  <td> <?php echo e($info->suggestion); ?></td>
                  <td> <?php echo e($info->schedule_vc); ?></td>
                  <td> <?php echo e($info->suggestion_medical_officer); ?></td>
                  <td class="text-center">
                      <a href="<?php echo e(route('edit', $info->id)); ?>" class="btn btn-primary btn-sm"">Edit</a>
                      <form action="<?php echo e(route('destroy', $info->id)); ?>" method="post" style="display: inline-block">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('DELETE'); ?>
                          <button class="btn btn-danger btn-sm"" type="submit">Delete</button>
                        </form>
                  </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EHR_System\resources\views/info/list.blade.php ENDPATH**/ ?>