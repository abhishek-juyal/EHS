<?php $__env->startSection('main'); ?>
<div class="row">
   <div class="col-sm-8 offset-sm-2">
      <h1 class="p-3 mb-2 bg-primary text-white" style="
    text-align: center;">Thank you for your submission.</h1>
    <a href="<?php echo e(route('info')); ?>"> Submit another.</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EHR_System\resources\views/info/thank.blade.php ENDPATH**/ ?>